<html>
<head>

<title>Product Cost Information System</title>
 <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
 <script src="js/jquery.js" type="text/javascript"></script>
</head>
<?php
include('dbcon.php');
?>